package urlcounts;
import java.io.IOException;
import java.text.*;
import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Map;
import java.util.stream.Collectors;

public class CountUrlHits {
    public static void main(String[] args) {
        if (args.length == 0)
            System.out.println("Enter the full path of input file like - /Users/akanungo/Desktop/NyansaTest/src/url.txt");
        String fileName = args[0];
        HashMap<String, HashMap<String, Integer>> map = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {

            String line;
            while ((line = br.readLine()) != null) {
                String[] a = line.split("\\|");
                SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
                formatter.setTimeZone(TimeZone.getTimeZone("GMT"));
                String d = formatter.format(new Date(Long.parseLong(a[0]) * 1000));
                if (map.containsKey(d)) {
                    if (map.get(d).containsKey(a[1])) {
                        map.get(d).put(a[1], map.get(d).get(a[1]) + 1);
                    } else {
                        map.get(d).put(a[1],1);
                    }

                } else {
                    HashMap<String, Integer> m = new HashMap<>();
                    m.put(a[1], 1);
                    map.put(d, m);
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        Map<Date, HashMap<String,Integer >> m1 = new TreeMap(map);
        System.out.println(m1);
        for(Map.Entry<Date,HashMap<String, Integer>> entry: m1.entrySet()){
            System.out.println( entry.getKey()+ " GMT");
            HashMap<String,Integer> values = entry.getValue();
            Map<String, Integer> sortedMap =
                    values.entrySet().stream()
                            .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
                            .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
                                    (e1, e2) -> e1, LinkedHashMap::new));
            for(Map.Entry<String, Integer> e: sortedMap.entrySet()){
                System.out.println(e.getKey()+" " +e.getValue());
            }
        }
    }
}
